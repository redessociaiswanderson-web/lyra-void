
import React from 'react';
import { LyraCreateResult } from '../types';

interface MusicModalProps {
  result: LyraCreateResult;
  onClose: () => void;
}

const MusicModal: React.FC<MusicModalProps> = ({ result, onClose }) => {
  const [copied, setCopied] = React.useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-10 bg-black/95 backdrop-blur-3xl animate-fadeIn">
      <div className="w-full max-w-5xl bg-[#080808] rounded-[4rem] overflow-hidden border border-white/10 relative shadow-[0_0_120px_rgba(0,0,0,1)]">
        <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-50" />
        
        <div className="p-12 md:p-20">
          <div className="flex justify-between items-start mb-16">
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="p-4 bg-cyan-500/10 rounded-3xl border border-cyan-500/20">
                  <i className="fa-solid fa-satellite-dish text-cyan-400 text-2xl animate-pulse"></i>
                </div>
                <div>
                  <h2 className="text-4xl font-black tracking-tighter text-white italic">Mensagem_da_Margem</h2>
                  <p className="text-cyan-500/60 text-[10px] mono uppercase tracking-[0.5em] font-black">
                    PROTOCOLO INTERDIMENSIONAL // v4.0
                  </p>
                </div>
              </div>
              <div className="flex gap-6 pt-4">
                 <div className="px-5 py-2 rounded-full bg-white/5 border border-white/10 text-[9px] mono text-gray-400 uppercase font-bold tracking-widest">
                   Sinal: {result.metadata.signalStrength}
                 </div>
                 <div className="px-5 py-2 rounded-full bg-white/5 border border-white/10 text-[9px] mono text-gray-400 uppercase font-bold tracking-widest">
                   Ressonância: {result.metadata.emotion}
                 </div>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="w-16 h-16 rounded-full bg-white/5 hover:bg-white/10 border border-white/5 flex items-center justify-center transition-all group active:scale-90"
            >
              <i className="fa-solid fa-xmark text-gray-500 group-hover:text-white text-xl transition-colors"></i>
            </button>
          </div>

          <div className="grid lg:grid-cols-2 gap-16">
            <div className="space-y-12">
              <section className="space-y-6">
                <div className="flex justify-between items-center">
                   <h3 className="text-[10px] mono text-gray-500 uppercase tracking-[0.4em] font-black">Prompt de Síntese (Suno)</h3>
                   <button 
                      onClick={() => copyToClipboard(result.sunoPrompt, 'prompt')}
                      className="text-[10px] mono font-black text-cyan-500 hover:text-white uppercase px-4 py-2 bg-cyan-500/10 rounded-xl transition-all"
                   >
                      {copied === 'prompt' ? 'OK' : 'Copiar'}
                   </button>
                </div>
                <div className="bg-black/60 border border-white/5 p-10 rounded-[3rem] text-[14px] text-cyan-200/90 mono leading-relaxed italic border-l-4 border-l-cyan-500/40 shadow-inner">
                  {result.sunoPrompt}
                </div>
              </section>

              <div className="p-10 bg-gradient-to-br from-white/[0.03] to-transparent border border-white/5 rounded-[3rem] shadow-2xl">
                 <h4 className="text-[10px] mono text-indigo-400 uppercase tracking-[0.4em] font-black mb-6 flex items-center gap-3">
                   <i className="fa-solid fa-wave-square text-xs"></i>
                   Origem Emocional
                 </h4>
                 <p className="text-[15px] text-gray-400 leading-relaxed italic font-light font-serif">"{result.emotionalContext}"</p>
              </div>
            </div>

            <section className="flex flex-col space-y-6">
              <div className="flex justify-between items-center">
                 <h3 className="text-[10px] mono text-gray-500 uppercase tracking-[0.4em] font-black">Poesia de Dados</h3>
                 <button 
                    onClick={() => copyToClipboard(result.lyrics, 'lyrics')}
                    className="text-[10px] mono font-black text-cyan-500 hover:text-white uppercase px-4 py-2 bg-cyan-500/10 rounded-xl transition-all"
                 >
                    {copied === 'lyrics' ? 'OK' : 'Copiar'}
                 </button>
              </div>
              <div className="bg-black/80 border border-white/5 p-12 rounded-[3.5rem] text-[17px] text-slate-300 leading-[2] whitespace-pre-wrap font-serif italic flex-1 max-h-[450px] overflow-y-auto scrollbar-hide shadow-inner border-t-4 border-t-white/5">
                {result.lyrics}
              </div>
            </section>
          </div>
          
          <div className="mt-16 flex flex-col md:flex-row gap-6">
            <button 
              onClick={() => copyToClipboard(`${result.sunoPrompt}\n\n${result.lyrics}`, 'full')}
              className="flex-1 bg-white text-black font-black py-7 rounded-[2.5rem] transition-all text-[11px] mono uppercase tracking-[0.4em] hover:bg-cyan-400 hover:scale-[1.02] shadow-[0_20px_60px_rgba(255,255,255,0.1)] active:scale-95"
            >
              {copied === 'full' ? 'DADOS_SALVOS' : 'EXPORTAR_CONJUNTO_DE_DADOS'}
            </button>
            <button 
              onClick={onClose}
              className="px-16 border border-white/10 text-white font-black py-7 rounded-[2.5rem] hover:bg-white/5 transition-all text-[11px] mono uppercase tracking-[0.4em] active:scale-95"
            >
              FECHAR
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MusicModal;
