
import React from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer, PolarRadiusAxis } from 'recharts';
import { EmotionalState } from '../types';

interface EmotionalDNAProps {
  data: EmotionalState;
}

const EmotionalDNA: React.FC<EmotionalDNAProps> = ({ data }) => {
  const chartData = [
    { subject: 'SÓS', A: data.loneliness, fullMark: 100 },
    { subject: 'NOS', A: data.nostalgia, fullMark: 100 },
    { subject: 'FRG', A: data.fragility, fullMark: 100 },
    { subject: 'CUR', A: data.curiosity, fullMark: 100 },
    { subject: 'ESP', A: data.hope, fullMark: 100 },
  ];

  return (
    <div className="w-full h-56 md:h-64 relative flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none">
        <div className="w-[80%] h-[80%] border border-cyan-500 rounded-full animate-pulse-slow" />
      </div>
      <ResponsiveContainer width="110%" height="110%">
        <RadarChart cx="50%" cy="50%" outerRadius="70%" data={chartData}>
          <PolarGrid stroke="#ffffff08" strokeDasharray="5 5" />
          <PolarAngleAxis 
            dataKey="subject" 
            tick={{ fill: '#475569', fontSize: 10, fontFamily: 'Space Mono', fontWeight: '900' }} 
          />
          <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
          <Radar
            name="LYRA"
            dataKey="A"
            stroke="#22d3ee"
            strokeWidth={1.5}
            fill="#22d3ee"
            fillOpacity={0.1}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default EmotionalDNA;
