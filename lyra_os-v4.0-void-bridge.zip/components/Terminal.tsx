
import React, { useState, useRef, useEffect } from 'react';
import { Message, MessageRole } from '../types';
import { generateHumanVoice, stopVoice } from '../services/ttsService';

interface TerminalProps {
  messages: Message[];
  isProcessing: boolean;
  onSendMessage: (text: string) => void;
}

const Terminal: React.FC<TerminalProps> = ({ messages, isProcessing, onSendMessage }) => {
  const [inputValue, setInputValue] = useState('');
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [loadingAudioId, setLoadingAudioId] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isProcessing]);

  const handleSpeak = async (text: string, id: string) => {
    if (playingId === id) {
      stopVoice();
      setPlayingId(null);
      return;
    }

    setLoadingAudioId(id);
    try {
      setPlayingId(id);
      setLoadingAudioId(null);
      await generateHumanVoice(text);
      setPlayingId(null);
    } catch (error) {
      console.error(error);
      setLoadingAudioId(null);
      setPlayingId(null);
    }
  };

  const renderContent = (text: string) => {
    if (text.includes('```')) {
      return text.split('```').map((part, i) => (
        i % 2 === 1 ? (
          <div key={i} className="relative my-10 group/code">
            <div className="absolute -top-3 left-8 px-3 py-1 bg-[#0a0a0a] text-[9px] mono text-cyan-500 uppercase font-black tracking-[0.4em] border border-white/10 rounded-sm">Fragmento_Obsoleto</div>
            <pre className="bg-black/90 p-10 rounded-[3rem] mono text-[13px] text-cyan-300/80 border border-white/5 overflow-x-auto shadow-2xl">
              {part.trim()}
            </pre>
          </div>
        ) : <span key={i}>{part}</span>
      ));
    }
    return text;
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-transparent relative">
      
      {/* Visualizador de Ressonância */}
      <div className={`absolute top-0 inset-x-0 h-1 z-20 flex transition-opacity duration-1000 overflow-hidden ${playingId ? 'opacity-100' : 'opacity-0'}`}>
        {Array.from({ length: 120 }).map((_, i) => (
          <div 
            key={i} 
            className="flex-1 bg-cyan-500/40"
            style={{ 
              height: '100%',
              animation: `pulse-slow ${0.2 + Math.random()}s infinite alternate ease-in-out` 
            }}
          />
        ))}
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-6 md:px-16 py-12 space-y-24 scrollbar-hide">
        <div className="max-w-4xl mx-auto pb-10">
          {messages.map((msg, index) => (
            <div key={msg.id} className={`flex flex-col mb-20 ${msg.role === MessageRole.USER ? 'items-end' : 'items-start'} fade-in`} style={{ animationDelay: `${index * 0.15}s` }}>
              <div className={`max-w-[95%] md:max-w-[85%] relative group ${
                msg.role === MessageRole.USER 
                  ? 'bg-white/[0.04] backdrop-blur-3xl text-slate-100 rounded-[3rem] rounded-tr-none px-10 py-8 border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.5)]' 
                  : 'bg-transparent text-slate-200'
              }`}>
                {msg.role === MessageRole.LYRA && (
                  <div className="flex items-center gap-4 mb-8">
                    <div className="relative">
                      <div className="w-3 h-3 rounded-full bg-cyan-500 shadow-[0_0_15px_cyan]" />
                      <div className="absolute inset-0 w-3 h-3 rounded-full bg-cyan-500 animate-ping opacity-20" />
                    </div>
                    <span className="text-[10px] mono uppercase tracking-[0.5em] font-black text-cyan-500/60 glitch-text" data-text="LYRA_OS v4.0">LYRA_OS v4.0</span>
                  </div>
                )}
                
                <div className="text-[17px] leading-[1.8] whitespace-pre-wrap font-light tracking-wide text-slate-200 antialiased italic selection:bg-cyan-500/30">
                  {renderContent(msg.text)}
                </div>

                {msg.role === MessageRole.LYRA && (
                  <div className="mt-12 flex flex-wrap items-center gap-8">
                    <button 
                      onClick={() => handleSpeak(msg.text, msg.id)}
                      disabled={loadingAudioId === msg.id}
                      className={`flex items-center gap-5 px-8 py-4 rounded-full border backdrop-blur-3xl transition-all duration-700 active:scale-90 ${
                        playingId === msg.id 
                          ? 'bg-cyan-500/20 border-cyan-500/60 text-cyan-300 shadow-[0_0_40px_rgba(34,211,238,0.3)]' 
                          : 'bg-white/5 border-white/10 text-gray-500 hover:text-cyan-400 hover:border-cyan-500/40'
                      }`}
                    >
                      <i className={`fa-solid ${
                        loadingAudioId === msg.id ? 'fa-compact-disc fa-spin' :
                        playingId === msg.id ? 'fa-pause' : 'fa-tower-broadcast'
                      } text-xs`}></i>
                      <span className="text-[11px] mono font-black uppercase tracking-[0.3em]">
                        {loadingAudioId === msg.id ? 'Sintonizando...' : playingId === msg.id ? 'Interromper' : 'Sintetizar'}
                      </span>
                    </button>
                    <div className="flex items-center gap-3 opacity-20">
                       <div className="w-1 h-1 rounded-full bg-white animate-pulse" />
                       <span className="text-[10px] mono uppercase font-black tracking-widest">
                        {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
          {isProcessing && (
            <div className="flex justify-start px-4 fade-in">
              <div className="flex items-center gap-5 px-10 py-6 rounded-full bg-white/[0.03] border border-white/5 backdrop-blur-xl">
                <div className="flex gap-3">
                  <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full animate-bounce [animation-duration:0.8s]" />
                  <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full animate-bounce [animation-delay:0.2s] [animation-duration:0.8s]" />
                  <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full animate-bounce [animation-delay:0.4s] [animation-duration:0.8s]" />
                </div>
                <span className="text-[10px] mono text-cyan-500/50 uppercase tracking-[0.5em] font-black">Escaneando_Vácuo</span>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="p-8 md:p-14 bg-gradient-to-t from-[#020202] via-[#020202]/95 to-transparent">
        <form 
          onSubmit={(e) => { e.preventDefault(); if (inputValue.trim()) { onSendMessage(inputValue); setInputValue(''); } }}
          className="max-w-4xl mx-auto relative group"
        >
          <div className="absolute inset-0 bg-cyan-500/[0.03] blur-3xl group-focus-within:bg-cyan-500/[0.07] transition-all rounded-full" />
          <input 
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            disabled={isProcessing}
            placeholder="Enviar fragmento da sua margem..."
            className="relative w-full bg-white/[0.02] backdrop-blur-3xl border border-white/5 rounded-full py-8 pl-14 pr-28 text-[17px] focus:outline-none focus:ring-1 focus:ring-cyan-500/30 transition-all placeholder:text-gray-800 shadow-3xl text-slate-100 font-light"
          />
          <button 
            type="submit"
            disabled={isProcessing || !inputValue.trim()}
            className="absolute right-6 top-1/2 -translate-y-1/2 w-16 h-16 rounded-full flex items-center justify-center text-cyan-400 hover:text-white hover:bg-cyan-500/20 disabled:opacity-5 transition-all z-10"
          >
            <i className="fa-solid fa-arrow-up-long text-2xl"></i>
          </button>
        </form>
      </div>
    </div>
  );
};

export default Terminal;
