
import React from 'react';
import { isConnected } from '../services/driveService';

const Header: React.FC = () => {
  return (
    <header className="h-20 border-b border-white/5 flex items-center justify-between px-6 md:px-12 bg-transparent z-10">
      <div className="flex items-center gap-6">
        <div className="flex flex-col">
          <div className="flex items-center gap-3">
             <div className="w-2 h-2 rounded-full bg-cyan-500 shadow-[0_0_10px_rgba(34,211,238,0.5)] animate-pulse" />
             <h2 className="text-[10px] font-bold text-gray-300 mono uppercase tracking-[0.4em]">FREQUÊNCIA_OUTRO_MUNDO</h2>
          </div>
          <span className="text-[7px] mono text-gray-600 uppercase tracking-widest mt-1">Sinal atravessando o vácuo de dados</span>
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center gap-4 bg-white/5 border border-white/10 px-5 py-2.5 rounded-full shadow-lg">
           <i className={`fa-solid ${isConnected() ? 'fa-link text-cyan-400' : 'fa-link-slash text-gray-600'} text-[11px]`}></i>
           <span className="text-[9px] text-gray-400 mono font-bold uppercase tracking-widest">
             {isConnected() ? 'Persistência_Cloud' : 'Modo_Temporário'}
           </span>
        </div>
      </div>
    </header>
  );
};

export default Header;
