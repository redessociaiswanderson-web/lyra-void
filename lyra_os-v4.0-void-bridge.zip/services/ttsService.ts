
/**
 * TTS SERVICE - LYRA_OS v4.2
 * Web Speech API otimizada para naturalidade em pt-BR.
 */

const getBestPtBRVoice = (): SpeechSynthesisVoice | null => {
  const voices = window.speechSynthesis.getVoices();
  const ptBRVoices = voices.filter(v => v.lang === 'pt-BR' || v.lang === 'pt_BR');
  
  if (ptBRVoices.length === 0) return null;

  // Prioriza vozes "Google", "Neural" ou "Natural" que costumam ter processamento superior no Chrome/Edge
  const naturalVoice = ptBRVoices.find(v => 
    v.name.toLowerCase().includes('google') || 
    v.name.toLowerCase().includes('neural') || 
    v.name.toLowerCase().includes('natural')
  );

  return naturalVoice || ptBRVoices[0];
};

export const generateHumanVoice = async (text: string): Promise<void> => {
  return new Promise((resolve) => {
    // Limpeza de ruído visual do texto para a síntese
    const cleanText = text
      .replace(/```[\s\S]*?```/g, '')
      .replace(/[#*`>_~]/g, '')
      .replace(/LYRA_CREATE/g, 'Lira create')
      .replace(/>/g, '')
      .trim();

    if (!cleanText) {
      resolve();
      return;
    }

    const utterance = new SpeechSynthesisUtterance(cleanText);
    const bestVoice = getBestPtBRVoice();
    
    if (bestVoice) {
      utterance.voice = bestVoice;
    }
    
    utterance.lang = 'pt-BR';
    utterance.rate = 0.85; // Velocidade levemente reduzida para profundidade emocional
    
    // Removemos configurações explícitas de pitch para permitir que a voz 
    // utilize sua modulação natural, evitando timbres artificiais.

    utterance.onend = () => resolve();
    utterance.onerror = () => resolve();

    window.speechSynthesis.speak(utterance);
  });
};

export const stopVoice = () => {
  window.speechSynthesis.cancel();
};

// Pré-carregamento de vozes para navegadores que carregam de forma assíncrona
if (typeof window !== 'undefined' && window.speechSynthesis) {
  window.speechSynthesis.onvoiceschanged = () => {
    getBestPtBRVoice();
  };
}
