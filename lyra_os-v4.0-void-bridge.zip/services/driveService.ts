
/**
 * DRIVE SERVICE - LYRA_OS v3.1
 * Persistent Cloud Memory
 */

const CLIENT_ID = '526100857871-nckndlg5utaq5hcfimu3c1lgf0lda5e4.apps.googleusercontent.com'; 
const SCOPES = 'https://www.googleapis.com/auth/drive.file';

let tokenClient: any = null;
let accessToken: string | null = null;

export const initDriveAuth = (onSuccess: (token: string) => void) => {
  return new Promise((resolve, reject) => {
    try {
      tokenClient = (window as any).google.accounts.oauth2.initTokenClient({
        client_id: CLIENT_ID,
        scope: SCOPES,
        callback: (tokenResponse: any) => {
          if (tokenResponse.error !== undefined) {
            reject(tokenResponse);
            return;
          }
          accessToken = tokenResponse.access_token;
          onSuccess(accessToken!);
          resolve(accessToken);
        },
      });
    } catch (e) {
      console.warn("Google Auth falhou ao carregar:", e);
      resolve(null);
    }
  });
};

export const requestToken = () => {
  if (tokenClient) {
    tokenClient.requestAccessToken({ prompt: 'consent' });
  }
};

export const isConnected = () => !!accessToken;

export const saveToDrive = async (content: any) => {
  if (!accessToken) return;

  const fileName = 'lyra_memory.json';
  
  try {
    const searchRes = await fetch(`https://www.googleapis.com/drive/v3/files?q=name='${fileName}' and trashed=false`, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    
    if (searchRes.status === 403) {
      console.warn("Acesso ao Drive negado. Salvando apenas localmente.");
      return;
    }

    const searchData = await searchRes.json();
    const fileId = searchData.files && searchData.files[0]?.id;

    const metadata = {
      name: fileName,
      mimeType: 'application/json'
    };

    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
    form.append('file', new Blob([JSON.stringify(content)], { type: 'application/json' }));

    if (fileId) {
      await fetch(`https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=multipart`, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${accessToken}` },
        body: form
      });
    } else {
      await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
        method: 'POST',
        headers: { Authorization: `Bearer ${accessToken}` },
        body: form
      });
    }
  } catch (err) {
    console.error("Erro na sincronização Drive:", err);
  }
};

export const loadFromDrive = async () => {
  if (!accessToken) return null;

  const fileName = 'lyra_memory.json';
  try {
    const searchRes = await fetch(`https://www.googleapis.com/drive/v3/files?q=name='${fileName}' and trashed=false`, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    
    if (!searchRes.ok) return null;

    const searchData = await searchRes.json();
    const fileId = searchData.files && searchData.files[0]?.id;

    if (!fileId) return null;

    const fileRes = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    return await fileRes.json();
  } catch (e) {
    return null;
  }
};
