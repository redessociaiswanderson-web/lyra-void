
import { Message, EmotionalState } from '../types';

const STORAGE_KEY = 'lyra_session_v3_3';

export interface SessionData {
  messages: Message[];
  emotionalState: EmotionalState;
  lastUpdate: number;
}

export const saveLocalSession = (data: SessionData) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
};

export const loadLocalSession = (): SessionData | null => {
  const data = localStorage.getItem(STORAGE_KEY);
  if (!data) return null;
  try {
    return JSON.parse(data);
  } catch {
    return null;
  }
};

export const clearLocalSession = () => {
  localStorage.removeItem(STORAGE_KEY);
};
