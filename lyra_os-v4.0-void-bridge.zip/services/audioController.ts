
/**
 * AUDIO CONTROLLER - LYRA_OS v3.1
 * Gerenciador central de reprodução para evitar conflitos de áudio.
 */

class AudioController {
  private static instance: AudioController;
  private currentAudio: HTMLAudioElement | null = null;
  private onStopCallback: (() => void) | null = null;

  private constructor() {}

  static getInstance(): AudioController {
    if (!AudioController.instance) {
      AudioController.instance = new AudioController();
    }
    return AudioController.instance;
  }

  stop() {
    if (this.currentAudio) {
      this.currentAudio.pause();
      this.currentAudio = null;
    }
    if (this.onStopCallback) {
      this.onStopCallback();
      this.onStopCallback = null;
    }
  }

  play(audio: HTMLAudioElement, onStart?: () => void, onEnd?: () => void) {
    this.stop();
    this.currentAudio = audio;
    this.onStopCallback = onEnd || null;

    audio.onplay = () => onStart?.();
    audio.onended = () => {
      onEnd?.();
      this.currentAudio = null;
      this.onStopCallback = null;
    };
    audio.onerror = () => {
      onEnd?.();
      this.currentAudio = null;
      this.onStopCallback = null;
    };

    audio.play().catch(console.error);
  }
}

export const audioController = AudioController.getInstance();
