
/**
 * ELEVENLABS SERVICE - LYRA_OS v3.1
 * Voice: TIb1FHpzlwSiTGg6JxF0 (Humana/Íntima)
 */

const VOICE_ID = 'TIb1FHpzlwSiTGg6JxF0';
const API_KEY = 'sk_92d2719013c7318d03b3ddef4d0b18e1bfe8a4fe0fe8fafa';

export const generateAudio = async (text: string): Promise<HTMLAudioElement> => {
  // Limpeza de texto para não ler códigos ou markdown
  const cleanText = text
    .replace(/```[\s\S]*?```/g, '')
    .replace(/[#*`>_~]/g, '')
    .replace(/LYRA_CREATE/g, 'Lira create')
    .trim();

  const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${VOICE_ID}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'xi-api-key': API_KEY,
    },
    body: JSON.stringify({
      text: cleanText,
      model_id: 'eleven_multilingual_v2',
      voice_settings: {
        stability: 0.5,
        similarity_boost: 0.9,
      }
    }),
  });

  if (!response.ok) {
    throw new Error('Falha na síntese ElevenLabs: ' + response.statusText);
  }

  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  return new Audio(url);
};
